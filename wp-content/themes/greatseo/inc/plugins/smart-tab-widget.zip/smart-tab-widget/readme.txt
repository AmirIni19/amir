=== Smart Tab Widget ===
Contributors: wpmagtheme
Creator's website link: http://wpmagtheme.com/
Tags: tab widget, recent posts, popular posts, tabs widget, ajax tabs, ajax widget.
Requires at least: 4.0.0
Tested up to: 4.7.5
Stable tag: 1.0.0
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Shows a tabbed widget for most popular, most commented, latest posts and tags using AJAX loading

== Description ==

Smart Tab Widget is a wordpress plugin. Shows a tabbed widget for most popular, most commented, latest posts and tags, reduce page loading time by using ajax loading!

= Live demos: = 
<a href="http://wpmagtheme.com/demo/smart_tabs/">http://wpmagtheme.com/demo/smart_tabs/</a>


== Installation ==

This section describes how to install the plugin and get it working.

1. Upload the `smart-tab-widget` folder to the to the `/wp-content/plugins/` directory
2. Activate the plugin through the 'Plugins' menu in WordPress
3. You can see **Smart Tab Widget** widget in widgets section.
4. Add it in sidebar and footer and configure as you want.
5. Enjoy!

== Screenshots ==

1. Smart Tab Widget
2. Smart Tab Widget
3. Settings 1
4. Settings 2
5. Settings 3

== Changelog ==
= 1.0 =
* Official plugin release.
